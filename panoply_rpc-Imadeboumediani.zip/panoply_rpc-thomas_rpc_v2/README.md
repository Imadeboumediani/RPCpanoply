# panoply_rpc
Micro project RPC

